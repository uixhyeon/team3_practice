# project_start

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Customize configuration

See [Vite Configuration Reference](https://vite.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
# vue_team2


==============변경해야할 것(완료시 체크하기)========================
10-14 index의 seo 변경 & public의 파비콘 이미지파일 바꾸기
10-17 views>mains 안의 파일들을 components>main-com으로 옮기기. 옮긴 후 라우터 import 바꾸기


===========상의해봐야 할것========================
만들 서비스들을 구체화 > 질문 대비.

================================
npm install @vuepic/vue-datepicker